
import React, { useState, useEffect, useCallback } from 'react';
import { generateTravelPlan } from './services/geminiService';
import type { TravelPlan, ViewType } from './types';
import { NAV_ITEMS } from './constants';
import ItineraryView from './components/ItineraryView';
import BudgetView from './components/BudgetView';
import MapView from './components/MapView';
import PackingListView from './components/PackingListView';
import SafetyTipsView from './components/SafetyTipsView';
import BottomNavBar from './components/BottomNavBar';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorMessage from './components/ErrorMessage';
import Header from './components/Header';

const App: React.FC = () => {
  const [travelPlan, setTravelPlan] = useState<TravelPlan | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [activeView, setActiveView] = useState<ViewType>('itinerary');

  const initialPrompt = "3-day budget trip to Goa with friends, beaches + nightlife";

  const fetchTravelPlan = useCallback(async (prompt: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const plan = await generateTravelPlan(prompt);
      setTravelPlan(plan);
    } catch (err) {
      setError('Failed to generate travel plan. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTravelPlan(initialPrompt);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleRegenerate = (newPrompt: string) => {
    const fullPrompt = `${initialPrompt}, but ${newPrompt}`;
    fetchTravelPlan(fullPrompt);
  };

  const renderContent = () => {
    if (!travelPlan) return null;

    switch (activeView) {
      case 'itinerary':
        return <ItineraryView itinerary={travelPlan.itinerary} onRegenerate={handleRegenerate} />;
      case 'budget':
        return <BudgetView budget={travelPlan.budget} />;
      case 'map':
        return <MapView locations={travelPlan.mapLocations} />;
      case 'packing':
        return <PackingListView items={travelPlan.packingList} />;
      case 'safety':
        return <SafetyTipsView tips={travelPlan.safetyTips} />;
      default:
        return <ItineraryView itinerary={travelPlan.itinerary} onRegenerate={handleRegenerate} />;
    }
  };

  return (
    <div className="min-h-screen font-sans bg-brand-accent/20">
      <div className="container mx-auto max-w-lg min-h-screen shadow-2xl bg-white flex flex-col">
        {isLoading && <LoadingSpinner />}
        {error && !isLoading && <ErrorMessage message={error} onRetry={() => fetchTravelPlan(initialPrompt)} />}
        
        {travelPlan && !isLoading && !error && (
          <>
            <Header title={travelPlan.tripTitle} subtitle={travelPlan.tripSubtitle} />
            <main className="flex-grow p-4 pb-24 overflow-y-auto">
              {renderContent()}
            </main>
            <BottomNavBar activeView={activeView} setActiveView={setActiveView} />
          </>
        )}
      </div>
    </div>
  );
};

export default App;

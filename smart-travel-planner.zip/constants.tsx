
import React from 'react';
import type { NavItem } from './types';

export const NAV_ITEMS: NavItem[] = [
  {
    id: 'itinerary',
    label: 'Itinerary',
    icon: <i className="fa-solid fa-route text-2xl"></i>,
  },
  {
    id: 'budget',
    label: 'Budget',
    icon: <i className="fa-solid fa-wallet text-2xl"></i>,
  },
  {
    id: 'map',
    label: 'Map',
    icon: <i className="fa-solid fa-map-location-dot text-2xl"></i>,
  },
  {
    id: 'packing',
    label: 'Packing',
    icon: <i className="fa-solid fa-suitcase-rolling text-2xl"></i>,
  },
  {
    id: 'safety',
    label: 'Tips',
    icon: <i className="fa-solid fa-shield-halved text-2xl"></i>,
  },
];


import React from 'react';

interface ErrorMessageProps {
  message: string;
  onRetry: () => void;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ message, onRetry }) => {
  return (
    <div className="flex flex-col justify-center items-center h-full p-8 text-center">
        <div className="text-5xl text-red-500 mb-4">
            <i className="fa-solid fa-circle-exclamation"></i>
        </div>
      <h2 className="text-xl font-bold text-gray-800">Oops! Something went wrong.</h2>
      <p className="text-gray-600 my-2">{message}</p>
      <button
        onClick={onRetry}
        className="mt-4 px-6 py-2 bg-brand-primary text-white font-semibold rounded-lg shadow-md hover:bg-brand-dark transition-colors duration-300"
      >
        Try Again
      </button>
    </div>
  );
};

export default ErrorMessage;


import React from 'react';

interface HeaderProps {
    title: string;
    subtitle: string;
}

const Header: React.FC<HeaderProps> = ({ title, subtitle }) => {
    return (
        <header className="bg-brand-primary text-white p-4 shadow-lg rounded-b-2xl">
            <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
            <p className="text-brand-accent text-sm">{subtitle}</p>
        </header>
    );
};

export default Header;

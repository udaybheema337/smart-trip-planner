
import React from 'react';
import { NAV_ITEMS } from '../constants';
import type { ViewType } from '../types';

interface BottomNavBarProps {
  activeView: ViewType;
  setActiveView: (view: ViewType) => void;
}

const BottomNavBar: React.FC<BottomNavBarProps> = ({ activeView, setActiveView }) => {
  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-lg bg-white/80 backdrop-blur-sm border-t border-gray-200 shadow-[0_-5px_15px_-5px_rgba(0,0,0,0.1)]">
      <div className="flex justify-around items-center h-16">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id)}
            className={`flex flex-col items-center justify-center w-full transition-colors duration-200 ${
              activeView === item.id ? 'text-brand-primary' : 'text-gray-400 hover:text-brand-secondary'
            }`}
          >
            {item.icon}
            <span className="text-xs font-medium mt-1">{item.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export default BottomNavBar;

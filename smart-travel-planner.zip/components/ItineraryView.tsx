
import React, { useState } from 'react';
import type { DayItinerary, Activity } from '../types';

interface ItineraryViewProps {
  itinerary: DayItinerary[];
  onRegenerate: (prompt: string) => void;
}

const ActivityCard: React.FC<{ activity: Activity, icon: string, title: string }> = ({ activity, icon, title }) => (
    <div className="bg-white rounded-xl shadow-md p-4 mb-4 border border-gray-100">
        <div className="flex items-center mb-2">
            <i className={`${icon} text-brand-secondary text-xl mr-3`}></i>
            <h4 className="font-bold text-lg text-brand-dark">{title} - {activity.title}</h4>
        </div>
        <p className="text-gray-600 text-sm mb-2">{activity.description}</p>
        <div className="flex justify-between text-xs text-gray-500 pt-2 border-t">
            <span><i className="fa-solid fa-wallet mr-1"></i> {activity.budget}</span>
            <span><i className="fa-solid fa-location-dot mr-1"></i> {activity.location}</span>
        </div>
    </div>
);

const ItineraryView: React.FC<ItineraryViewProps> = ({ itinerary, onRegenerate }) => {
  const [selectedDay, setSelectedDay] = useState(1);
  const [newPrompt, setNewPrompt] = useState('');

  const currentDayData = itinerary.find((day) => day.day === selectedDay);

  const handleRegenerateClick = () => {
    if (newPrompt.trim()) {
        onRegenerate(newPrompt);
        setNewPrompt('');
    }
  }

  return (
    <div className="space-y-4">
      <div className="p-4 bg-brand-accent/50 rounded-xl">
        <p className="text-sm text-brand-dark mb-2">Want a different vibe?</p>
        <div className="flex space-x-2">
            <input 
                type="text" 
                value={newPrompt}
                onChange={(e) => setNewPrompt(e.target.value)}
                placeholder="e.g. 'more chill' or 'add adventure sports'"
                className="w-full px-3 py-2 text-sm border border-brand-secondary/50 rounded-lg focus:ring-brand-primary focus:border-brand-primary"
            />
            <button 
                onClick={handleRegenerateClick}
                className="px-4 py-2 bg-brand-secondary text-white font-semibold rounded-lg shadow-sm hover:bg-brand-primary transition-colors"
            >
                Regen
            </button>
        </div>
      </div>


      <div className="flex justify-center bg-gray-100 rounded-full p-1">
        {itinerary.map((day) => (
          <button
            key={day.day}
            onClick={() => setSelectedDay(day.day)}
            className={`w-full py-2 px-4 rounded-full text-sm font-semibold transition-all duration-300 ${
              selectedDay === day.day ? 'bg-brand-primary text-white shadow' : 'text-gray-600'
            }`}
          >
            Day {day.day}
          </button>
        ))}
      </div>

      {currentDayData && (
        <div className="animate-fade-in">
            <h3 className="text-xl font-bold text-brand-dark mb-4 text-center">{currentDayData.title}</h3>
            <ActivityCard activity={currentDayData.morning} icon="fa-solid fa-sun" title="Morning" />
            <ActivityCard activity={currentDayData.afternoon} icon="fa-solid fa-cloud-sun" title="Afternoon" />
            <ActivityCard activity={currentDayData.evening} icon="fa-solid fa-moon" title="Evening" />
            <ActivityCard activity={currentDayData.nightlife} icon="fa-solid fa-martini-glass-citrus" title="Nightlife" />
        </div>
      )}
    </div>
  );
};

export default ItineraryView;

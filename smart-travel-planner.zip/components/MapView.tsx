import React from 'react';
import type { MapLocation } from '../types';

interface MapViewProps {
  locations: MapLocation[];
}

const ICONS: { [key: string]: string } = {
  'Beach': 'fa-solid fa-umbrella-beach',
  'Restaurant': 'fa-solid fa-utensils',
  'Club': 'fa-solid fa-martini-glass-citrus',
  'Activity': 'fa-solid fa-person-swimming',
  'Shack': 'fa-solid fa-shop',
  'Attraction': 'fa-solid fa-camera-retro',
  'Default': 'fa-solid fa-location-dot',
}

const MapView: React.FC<MapViewProps> = ({ locations }) => {
    // Fix: Rewrote the reduce function to be more type-safe and explicit,
    // ensuring `groupedLocations` is correctly typed.
    const groupedLocations = locations.reduce((acc: Record<string, MapLocation[]>, loc) => {
        const type = loc.type;
        if (!acc[type]) {
            acc[type] = [];
        }
        acc[type].push(loc);
        return acc;
    }, {});

  return (
    <div className="space-y-4">
        <div className="relative rounded-xl overflow-hidden shadow-lg h-56">
            <img src="https://picsum.photos/800/400?blur=2&random=1" alt="Map of Goa" className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <p className="text-white text-lg font-semibold bg-black/50 px-4 py-2 rounded-lg">Interactive Map View</p>
            </div>
        </div>

        <div>
            <h3 className="text-xl font-bold text-brand-dark mb-3">Key Locations</h3>
            <div className="space-y-3">
                {Object.entries(groupedLocations).map(([type, locs]) => (
                    <div key={type}>
                        <h4 className="font-semibold text-gray-600 mb-2">{type}s</h4>
                        <ul className="bg-white p-2 rounded-xl shadow-md border border-gray-100 divide-y divide-gray-100">
                            {locs.map(loc => (
                                <li key={loc.name} className="flex items-center p-2">
                                    <i className={`${ICONS[type] || ICONS['Default']} text-brand-secondary w-6 text-center mr-3`}></i>
                                    <span className="text-gray-700">{loc.name}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                ))}
            </div>
        </div>
    </div>
  );
};

export default MapView;
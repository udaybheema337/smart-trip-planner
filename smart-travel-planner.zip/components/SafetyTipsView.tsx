
import React from 'react';

interface SafetyTipsViewProps {
  tips: string[];
}

const SafetyTipsView: React.FC<SafetyTipsViewProps> = ({ tips }) => {
  return (
    <div>
        <h3 className="text-xl font-bold text-brand-dark mb-4">Safety & Travel Tips</h3>
        <ul className="space-y-3">
            {tips.map((tip, index) => (
                <li key={index} className="flex items-start p-4 bg-white rounded-xl shadow-md border border-gray-100">
                    <i className="fa-solid fa-shield-heart text-brand-primary text-xl mt-1 mr-4"></i>
                    <p className="text-gray-700">{tip}</p>
                </li>
            ))}
        </ul>
    </div>
  );
};

export default SafetyTipsView;

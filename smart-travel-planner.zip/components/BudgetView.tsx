
import React from 'react';
import type { BudgetItem } from '../types';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface BudgetViewProps {
  budget: BudgetItem[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#AF19FF', '#FF1943'];

const BudgetView: React.FC<BudgetViewProps> = ({ budget }) => {
    const totalBudget = budget.reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className="space-y-6">
      <div className="text-center p-4 bg-brand-accent/50 rounded-xl">
        <p className="text-brand-dark">Total Estimated Budget</p>
        <p className="text-4xl font-bold text-brand-primary">
            ₹{totalBudget.toLocaleString('en-IN')}
        </p>
      </div>
      
      <div className="bg-white p-4 rounded-xl shadow-md border border-gray-100">
        <h3 className="text-lg font-bold text-brand-dark mb-4 text-center">Budget Distribution</h3>
        <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer>
                <PieChart>
                <Pie
                    data={budget}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="amount"
                    nameKey="category"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                    {budget.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                </Pie>
                <Tooltip formatter={(value: number) => `₹${value.toLocaleString('en-IN')}`} />
                </PieChart>
            </ResponsiveContainer>
        </div>
      </div>
      
      <div className="bg-white p-4 rounded-xl shadow-md border border-gray-100">
        <h3 className="text-lg font-bold text-brand-dark mb-2">Expense Details</h3>
        <ul className="divide-y divide-gray-200">
            {budget.map((item, index) => (
                <li key={item.category} className="py-3 flex justify-between items-center">
                    <div className="flex items-center">
                        <span className="h-3 w-3 rounded-full mr-3" style={{ backgroundColor: COLORS[index % COLORS.length] }}></span>
                        <span className="font-medium text-gray-700">{item.category}</span>
                    </div>
                    <span className="font-semibold text-gray-800">₹{item.amount.toLocaleString('en-IN')}</span>
                </li>
            ))}
        </ul>
      </div>
    </div>
  );
};

export default BudgetView;

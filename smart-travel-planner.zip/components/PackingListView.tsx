
import React, { useState } from 'react';

interface PackingListViewProps {
  items: string[];
}

const PackingListItem: React.FC<{ item: string }> = ({ item }) => {
    const [isChecked, setIsChecked] = useState(false);

    return (
        <li 
            className={`flex items-center p-3 transition-all duration-300 rounded-lg cursor-pointer ${isChecked ? 'bg-green-100 text-gray-500 line-through' : 'bg-white hover:bg-gray-50'}`}
            onClick={() => setIsChecked(!isChecked)}
        >
            <div className="w-5 h-5 mr-4 border-2 border-brand-secondary rounded flex items-center justify-center">
                {isChecked && <i className="fa-solid fa-check text-brand-secondary text-xs"></i>}
            </div>
            <span className="flex-grow">{item}</span>
        </li>
    );
};


const PackingListView: React.FC<PackingListViewProps> = ({ items }) => {
  return (
    <div>
        <h3 className="text-xl font-bold text-brand-dark mb-4">Packing Checklist</h3>
        <p className="text-sm text-gray-500 mb-4">Tap on an item to mark it as packed.</p>
        <ul className="space-y-2">
            {items.map((item, index) => (
                <PackingListItem key={index} item={item} />
            ))}
        </ul>
    </div>
  );
};

export default PackingListView;

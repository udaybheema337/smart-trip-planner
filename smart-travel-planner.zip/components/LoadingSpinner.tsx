
import React from 'react';

const LoadingSpinner: React.FC = () => {
  return (
    <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex flex-col justify-center items-center z-50">
        <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-brand-primary"></div>
        <p className="mt-4 text-brand-dark font-semibold text-lg">Crafting your perfect trip...</p>
        <p className="text-gray-500">This might take a moment.</p>
    </div>
  );
};

export default LoadingSpinner;

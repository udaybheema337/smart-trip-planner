
import { GoogleGenAI, Type } from "@google/genai";
import type { TravelPlan } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const travelPlanSchema = {
    type: Type.OBJECT,
    properties: {
        appName: { type: Type.STRING },
        tripTitle: { type: Type.STRING },
        tripSubtitle: { type: Type.STRING },
        itinerary: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    day: { type: Type.INTEGER },
                    title: { type: Type.STRING },
                    morning: { 
                        type: Type.OBJECT,
                        properties: { title: {type: Type.STRING}, description: {type: Type.STRING}, budget: {type: Type.STRING}, location: {type: Type.STRING} },
                        required: ["title", "description", "budget", "location"]
                    },
                    afternoon: { 
                        type: Type.OBJECT,
                        properties: { title: {type: Type.STRING}, description: {type: Type.STRING}, budget: {type: Type.STRING}, location: {type: Type.STRING} },
                        required: ["title", "description", "budget", "location"]
                    },
                    evening: { 
                        type: Type.OBJECT,
                        properties: { title: {type: Type.STRING}, description: {type: Type.STRING}, budget: {type: Type.STRING}, location: {type: Type.STRING} },
                        required: ["title", "description", "budget", "location"]
                    },
                    nightlife: { 
                        type: Type.OBJECT,
                        properties: { title: {type: Type.STRING}, description: {type: Type.STRING}, budget: {type: Type.STRING}, location: {type: Type.STRING} },
                        required: ["title", "description", "budget", "location"]
                    },
                },
                required: ["day", "title", "morning", "afternoon", "evening", "nightlife"]
            }
        },
        budget: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    category: { type: Type.STRING },
                    amount: { type: Type.NUMBER },
                    percentage: { type: Type.NUMBER },
                },
                required: ["category", "amount", "percentage"]
            }
        },
        packingList: { type: Type.ARRAY, items: { type: Type.STRING } },
        safetyTips: { type: Type.ARRAY, items: { type: Type.STRING } },
        mapLocations: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    name: { type: Type.STRING },
                    type: { type: Type.STRING },
                },
                required: ["name", "type"]
            }
        }
    },
    required: ["appName", "tripTitle", "tripSubtitle", "itinerary", "budget", "packingList", "safetyTips", "mapLocations"]
};


export const generateTravelPlan = async (prompt: string): Promise<TravelPlan> => {
    const fullPrompt = `
    You are a senior product designer and travel expert. Your task is to generate a complete SMART TRAVEL PLANNER JSON object based on the user's travel request.
    User travel request: "${prompt}"

    Generate the output as a single, valid JSON object that strictly adheres to the provided schema. Do not include any markdown formatting like \`\`\`json or any explanatory text.

    Please provide a realistic and detailed plan for a budget-conscious trip. The budget should be calculated in Indian Rupees (INR). All locations and suggestions must be relevant to the user request.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: fullPrompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: travelPlanSchema,
                temperature: 0.7,
            },
        });
        
        const jsonText = response.text.trim();
        const plan = JSON.parse(jsonText);
        return plan;

    } catch (error) {
        console.error("Error generating travel plan from Gemini:", error);
        throw new Error("Failed to parse travel plan from AI response.");
    }
};

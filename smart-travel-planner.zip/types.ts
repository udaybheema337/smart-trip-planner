// Fix: Import ReactNode to correctly type JSX elements.
import type { ReactNode } from 'react';

export interface Activity {
  title: string;
  description: string;
  budget: string;
  location: string;
}

export interface DayItinerary {
  day: number;
  title: string;
  morning: Activity;
  afternoon: Activity;
  evening: Activity;
  nightlife: Activity;
}

export interface BudgetItem {
  category: string;
  amount: number;
  percentage: number;
}

export interface MapLocation {
  name: string;
  type: string;
}

export interface TravelPlan {
  appName: string;
  tripTitle: string;
  tripSubtitle: string;
  itinerary: DayItinerary[];
  budget: BudgetItem[];
  packingList: string[];
  safetyTips: string[];
  mapLocations: MapLocation[];
}

export type ViewType = 'itinerary' | 'budget' | 'map' | 'packing' | 'safety';

export interface NavItem {
    id: ViewType;
    label: string;
    // Fix: Use ReactNode for the icon property type.
    icon: ReactNode;
}